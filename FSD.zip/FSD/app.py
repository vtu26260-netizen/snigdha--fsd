from flask import render_template
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import (
    JWTManager, create_access_token,
    jwt_required, get_jwt_identity
)
from flask_cors import CORS
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///subscription.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'super-secret-key'

db = SQLAlchemy(app)
jwt = JWTManager(app)

# ---------------------
# Database Models
# ---------------------

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    plan = db.Column(db.String(50), default="Free")

class Subscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    plan = db.Column(db.String(50))
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
# ---------------------
# Register
# ---------------------
@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["POST"])
def register():
    data = request.json
    user = User(email=data['email'], password=data['password'])
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User registered successfully"})

# ---------------------
# Login
# ---------------------

@app.route("/login", methods=["POST"])
def login():
    data = request.json
    user = User.query.filter_by(email=data['email'], password=data['password']).first()

    if not user:
        return jsonify({"message": "Invalid credentials"}), 401

    token = create_access_token(identity=user.id)
    return jsonify(access_token=token)

# ---------------------
# Subscribe
# ---------------------

@app.route("/subscribe", methods=["POST"])
@jwt_required()
def subscribe():
    current_user_id = get_jwt_identity()
    data = request.json
    plan = data['plan']

    end_date = datetime.utcnow() + timedelta(days=30)

    subscription = Subscription(
        user_id=current_user_id,
        plan=plan,
        end_date=end_date
    )

    user = User.query.get(current_user_id)
    user.plan = plan

    db.session.add(subscription)
    db.session.commit()

    return jsonify({"message": f"Subscribed to {plan} plan"})

# ---------------------
# Protected Premium Content
# ---------------------

@app.route('/premium-content', methods=['GET'])
@jwt_required()
def premium_content():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    if user.plan != "Premium":
        return jsonify({"message": "Upgrade to Premium to access this content"}), 403

    return jsonify({"content": "Welcome to Premium Entertainment Content 🎬"})

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)

